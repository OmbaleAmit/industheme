<footer>
    <p> Indus Assignment </p>
</footer>   

</div> <!-- .container div ended -->

   </body>
</html>