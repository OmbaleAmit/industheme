<?php

/*
  	****************Include Scritps********************
*/

function indus1_script_enqueue(){

     wp_enqueue_style('customstyle', get_template_directory_uri() . '/css/indus.css', array(), '1.0.0', 'all');
     wp_enqueue_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css', array(), '3.3.7', 'all');
     wp_enqueue_style('jequery');
     wp_enqueue_style('customjs', get_template_directory_uri() . '/js/indus.js', array(), '1.0.0', true);
     wp_enqueue_style('bootstrapjs', get_template_directory_uri() . '/js/bootstrap.min.js', array(), '3.3.7', true);
    
}

add_action('wp_enqueue_scripts', 'indus1_script_enqueue');


/*
  	****************Activate Menus********************
*/
function indus_theme_setup(){
       add_theme_support('menus');
       register_nav_menu('primary','Primary Header Navigation');
}

add_action('init', 'indus_theme_setup');


/*
  	****************Theme support Functions********************
*/
add_theme_support('custom-background');
add_theme_support('custom-header');
add_theme_support('post-thumbnails', array('post', 'page'));
add_theme_support( 'post-thumbnails' );

add_theme_support('post-formats', array('aside','image','video'));
