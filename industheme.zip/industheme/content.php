<div class="thumbnail-img"><?php the_post_thumbnail(); ?></div>
	<p> <?php the_content(); ?> </p>
	<hr>