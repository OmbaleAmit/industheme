<h3><?php the_title(); ?> </p></h3>
<hr>